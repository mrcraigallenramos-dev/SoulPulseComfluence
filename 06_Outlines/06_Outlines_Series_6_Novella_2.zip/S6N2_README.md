﻿# Series 6 â€“ Novella 2: The Hidden Architects

Archaeological discovery of shadow manipulation network. Hidden architects with foundational access. Systematic consciousness control throughout history. Universal resistance formed. No Tiffani; anonymous Auditor.

Interludes:
- IntA after CH02
- IntB after CH08

Files:
- Chapters S6N2_CH01 â€¦ S6N2_CH13
- Interludes S6N2_IntA, S6N2_IntB
- Epilogue S6N2_Epilogue