﻿# Series 4 â€“ Novella 1: Echoes of Oblivion

Post-transcendence reconstruction under new governance. Cosmic relics recovered, decontaminated, and stewarded. Insurgency suppressed; oversight charter ratified. All without hint of Tiffani; Auditor remains anonymous.

Interludes:
- IntA after CH03
- IntB after CH09

Files:
- Chapters S4N1_CH01 â€¦ S4N1_CH13
- Interludes S4N1_IntA, S4N1_IntB
- Epilogue S4N1_Epilogue