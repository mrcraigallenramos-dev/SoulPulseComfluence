﻿# Series 4 â€“ Novella 5: Ascensionâ€™s End

Final threshold choices, cosmic integration, mortal-ascendant unity, Ascension Codex published. No Tiffani; Auditor remains anonymous.