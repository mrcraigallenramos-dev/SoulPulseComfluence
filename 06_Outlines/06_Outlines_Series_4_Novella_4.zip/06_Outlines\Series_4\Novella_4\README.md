﻿# Series 4 â€“ Novella 4: Cosmic Renaissance

Urban and frontier renaissance, Floating Cities expansion, prototype archaeology, cosmic heritage programs. Full cosmic-human synergy under anonymous Auditor.