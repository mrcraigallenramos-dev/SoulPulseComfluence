﻿---
series: 5
novella: 3
file: S5N3_IntA
type: interlude
label: A
pov: Auditor
setting: Room-not-room â€“ anomaly audit
word_target_min: 801
word_target_max: 1299
status: outline
---
Logline: The Auditor audits anomaly adaptation, tweaking parameters to maintain team integrity and sanity amid existential instability.

Beats:
- Crew cohesion metrics tied to survival.
- Adaptation variables recalibrated to dampen cognitive fragmentation.
- Probability thresholds lowered for creative risk solutions.
- Exit: Odyssey phase adapts with meta-protocol updates.