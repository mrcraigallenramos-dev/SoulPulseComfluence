﻿# Series 4 â€“ Novella 2: Shadows of Renaissance

Frontier adaptation and relic-driven renaissance under new governance. Independent settlements innovate, governance charters extended, and ethical debates shape future. Auditor remâ€‹ains anonymous.

Interludes:
- IntA after CH02
- IntB after CH08

Files:
- Chapters S4N2_CH01 â€¦ S4N2_CH13
- Interludes S4N2_IntA, S4N2_IntB
- Epilogue S4N2_Epilogue