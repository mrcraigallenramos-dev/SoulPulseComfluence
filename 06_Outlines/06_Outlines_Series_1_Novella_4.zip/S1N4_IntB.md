﻿---
series: 1
novella: 4
file: S1N4_IntB
type: interlude
label: B
pov: Salee
setting: Resistance bunkerâ€”hidden archives
word_target_min: 801
word_target_max: 1299
status: outline
---
Logline: Salee uncovers counter-intelligence logs exposing the Gatekeeper Protocol, galvanizing the underground into a final stand against cosmic tyranny.

Beats:
- Hidden logs project the Gate's activation timeline; she traces each rebel cell's role in delay tactics.
- Allies volunteer to sabotage conduits; whispers of divine justice spread through the network.
- Salee's locket pulses in resonance with the Gateâ€”guiding her to allies who still believe in human agency.
- The bunker's door seals as alarms echoâ€”her people ready, weapons drawn, hearts ignited.