﻿---
series: 1
novella: 4
file: S1N4_IntA
type: interlude
label: A
pov: Corlexi/Xilcore
setting: Counter-Spark shrine
word_target_min: 801
word_target_max: 1299
status: outline
---
Logline: Xilcore forges a new Pact, binding the Hollowgate's raw power to her will, trading shards of her humanity for divine resonance.

Beats:
- The shrine's altar glows with black flame; Corlexi offers her echo of identity as tithe.
- Counter-Spark servants weave her shadow into the ritual, each strand demanding a memory of her past.
- The altar drinkâ€”liquid geometryâ€”burns through her ego, leaving a hollow core that fills with cosmic intent.
- Xilcore emerges with eyes like fractured light, mind thrumming with ancient equations.
- Exit: she communes silently with the Hollowgate, preparing to activate the gate's true key.