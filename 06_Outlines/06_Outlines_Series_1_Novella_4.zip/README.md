﻿# Series 1 â€“ Novella 4: The Hollowgate

This folder contains the outline for **Series 1, Novella 4** of _The Confluence Chronicles_.

Files:
- S1N4_CH01.md â€¦ S1N4_CH02.md
- S1N4_IntA.md â€“ Interlude A (after CH02)
- S1N4_CH03.md â€¦ S1N4_CH07.md
- S1N4_IntB.md â€“ Interlude B (after CH07)
- S1N4_CH08.md â€¦ S1N4_CH13.md
- S1N4_Epilogue.md

Word count targets:
- Chapters: 1201â€“2299 words
- Interludes: 801â€“1299 words
- Epilogue: 600â€“800 words