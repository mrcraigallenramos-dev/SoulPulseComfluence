﻿# Series 2 - Novella 4: The Clockwork Rebellion

Three years post-integration. Catalysts discover faction harmony masks systematic personality suppression. Underground network documents control mechanisms while gods recognize perfect order threatens cosmic balance. Coordinated revelation restores authentic choice and individual agency.

Interlude placement:
- Interlude A: after CH01
- Interlude B: after CH07

Files
- Chapters: S2N4_CH01 through S2N4_CH13
- Interludes: S2N4_IntA (Auditor), S2N4_IntB (Blemo)
- Epilogue: S2N4_Epilogue

Targets
- Chapters 1201-2299 words
- Interludes 801-1299 words
- Epilogue 600-800 words