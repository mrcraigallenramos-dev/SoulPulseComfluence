﻿---
series: 1
novella: 1
file: S1N1_IntA
type: interlude
label: A
pov: Corlexi (mortal; future identity unrevealed)
setting: Scriptorium
word_target_min: 801
word_target_max: 1299
status: outline
---
Logline: Corlexi commits a small sinâ€”keeping a geometric chipâ€”and hears the world hum back as she edits doctrine about friction feeding the world.

Beats:
- Candlelight and cold fingers over heresy about the First Spark and â€œfurious symmetry,â€ irritation at brittle doctrine and hunger for pattern.
- A patron slides a margin to â€œcorrect,â€ hiding a proof that opposing wills generate the engine of existence, which tastes like truth to her.
- She pockets a geometry slip and catches a subharmonic ping in the stone, the choir growing a hair brighter.
- Exit: she plans to return after hours, calling it devotion while meaning conquest.