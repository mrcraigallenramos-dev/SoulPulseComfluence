﻿---
series: 1
novella: 1
file: S1N1_IntB
type: interlude
label: B
pov: Salee (mortal; future identity unrevealed)
setting: Gutters and stoops
word_target_min: 801
word_target_max: 1299
status: outline
---
Logline: Salee stitches favors and signals into a sheltering cult, learning flexibility beats brittle order when hunger rules.

Beats:
- Bread for signals grows into a following; rumor and name snowball into soft power.
- A rivalâ€™s rigid â€œorderâ€ collapses faster than her adaptive chaos; she files harmonyâ€‘asâ€‘flatline in her bones.
- A broken locket warms in her palm like a pulse; she smiles into rain and keeps walking.