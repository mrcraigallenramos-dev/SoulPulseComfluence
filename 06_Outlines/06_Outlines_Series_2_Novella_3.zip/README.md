﻿# Series 2 - Novella 3: Mechanisms of Control

Two years post-Fathombreak. Faction territories achieve genuine prosperity while resistance faces ideological crisis. Both Catalysts undergo conversion consultation and choose integration over continued opposition. Continental harmony achieved through voluntary transformation rather than conquest.

Interlude placement:
- Interlude A: after CH04
- Interlude B: after CH10

Files
- Chapters: S2N3_CH01 through S2N3_CH13
- Interludes: S2N3_IntA (Blemo), S2N3_IntB (Seeri)
- Epilogue: S2N3_Epilogue

Targets
- Chapters 1201-2299 words
- Interludes 801-1299 words
- Epilogue 600-800 words