﻿---
series: 1
novella: 2
file: S1N2_IntA
type: interlude
label: A
pov: Corlexi
setting: Cathedral undercroft - forbidden library
word_target_min: 801
word_target_max: 1299
status: outline
---
Logline: Corlexi finds the locked archives and discovers the First Spark wasn't singularâ€”it was a schism that created twin flames, and one of them is still burning.

Beats:
- Midnight descent through stone that remembers older prayers; the forbidden texts are bound in materials that warm to her touch.
- The revelation: creation required opposition, and the Counter-Spark exists as Spark's necessary shadowâ€”not evil, but essential friction.
- Ancient diagrams show paired god-minds: one building, one tearing down, both feeding reality's engine through their eternal argument.
- She pockets a fragment of living stone that whispers mathematical truths about divine symbiosis and the cost of cosmic balance.
- Exit decision: she will seek the Counter-Spark's servants, not to serve but to understand the equation that governs gods.