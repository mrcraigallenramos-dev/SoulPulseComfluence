﻿---
series: 2
novella: 1
file: S2N1_IntA
type: interlude
label: A
pov: Leesa
setting: Harmony heartland
word_target_min: 801
word_target_max: 1299
status: outline
---
Logline: Leesa counts the cost of peace and finds a bruise she cannot press flat.

Beats:
- Communes hum; art dims; arguments vanish; children smile the same smile.
- She models futures with zero painâ€”and zero surprise.
- A single grief note persists in her calculus: the Catalyst's refusal as necessary dissonance.
- She pauses her netâ€”an immortal's first restraint.