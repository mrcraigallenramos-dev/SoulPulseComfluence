﻿# Series 2 - Novella 1: Chains of the Gearlords

Tiffani is presumed dead; Jhace's uncontrolled hybrid outburst awakened four gods and global combat magic. Six months of faction chaos follow as gods recruit, convert, and cleanse. Jhace refuses every throne.

Interlude placement:
- Interlude A: after CH03
- Interlude B: after CH09

Files
- Chapters: S2N1_CH01 through S2N1_CH13
- Interludes: S2N1_IntA (Leesa), S2N1_IntB (Auditor)
- Epilogue: S2N1_Epilogue

Targets
- Chapters 1201-2299 words
- Interludes 801-1299 words
- Epilogue 600-800 words