﻿# Series 1 â€“ Novella 5: The Fractured Chorus

This folder contains the outline for **Series 1, Novella 5** of _The Confluence Chronicles_.

Files:
- S1N5_CH01.md â€¦ S1N5_CH04.md
- S1N5_IntA.md â€“ Interlude A (after CH04)
- S1N5_CH05.md â€¦ S1N5_CH09.md
- S1N5_IntB.md â€“ Interlude B (after CH09)
- S1N5_CH10.md â€¦ S1N5_CH13.md
- S1N5_Epilogue.md

Word count targets:
- Chapters: 1201â€“2299 words
- Interludes: 801â€“1299 words
- Epilogue: 600â€“800 words