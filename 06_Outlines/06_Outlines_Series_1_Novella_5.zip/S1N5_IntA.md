﻿---
series: 1
novella: 5
file: S1N5_IntA
type: interlude
label: A
pov: Xilcore
setting: Counter-Spark nexus - divine chess
word_target_min: 801
word_target_max: 1299
status: outline
---
Logline: Xilcore observes the Guild's harvesting operation and realizes both Spark and Counter-Spark benefit from the systematic weakeningâ€”divine entities playing chess with mortal civilizations.

Beats:
- The nexus exists outside linear time; Xilcore watches Guild operations across multiple cities simultaneously, seeing the pattern's full scope.
- Counter-Spark revelation: systematic weakening serves both divine aspects by creating controlled collapse and reconstruction cycles.
- She recognizes the Guild's leadership as willing servants of cosmic balance, trading human agency for divine stability and their own immortality.
- Moral choice crystallizes: warn the mortals and disrupt divine plans, or allow the cycle to continue and preserve cosmic equilibrium.
- Decision: she begins subtle interference, not to save humanity but to introduce necessary chaos into an overly ordered divine system.