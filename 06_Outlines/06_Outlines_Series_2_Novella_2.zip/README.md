﻿# Series 2 - Novella 2: The Grinding Gears

Eighteen months post-Fathombreak. Divine faction coordination increases while a second Catalyst emerges. Jhace and Kira work together as resistance evolves from survival to active liberation. Gods face internal conflicts between absolute nature and tactical requirements.

Interlude placement:
- Interlude A: after CH02
- Interlude B: after CH08

Files
- Chapters: S2N2_CH01 through S2N2_CH13
- Interludes: S2N2_IntA (Xilcore), S2N2_IntB (Seeri)
- Epilogue: S2N2_Epilogue

Targets
- Chapters 1201-2299 words
- Interludes 801-1299 words
- Epilogue 600-800 words