﻿# Series 1 â€“ Novella 3: The Silent Argument

This folder contains the outline for **Series 1, Novella 3** of _The Confluence Chronicles_.

Files:
- S1N3_CH01.md â€“ Chapter 1 outline
- S1N3_IntA.md â€“ Interlude A outline
- S1N3_CH02.md â€¦ through S1N3_CH06.md â€“ Chapters 2â€“6
- S1N3_IntB.md â€“ Interlude B outline
- S1N3_CH07.md â€¦ through S1N3_CH13.md â€“ Chapters 7â€“13
- S1N3_Epilogue.md â€“ Auditor epilogue

Word count targets:
- Chapters: 1201â€“2299 words
- Interludes: 801â€“1299 words
- Epilogue: 600â€“800 words