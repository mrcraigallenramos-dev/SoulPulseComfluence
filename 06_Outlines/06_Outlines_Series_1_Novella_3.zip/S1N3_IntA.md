﻿---
series: 1
novella: 3
file: S1N3_IntA
type: interlude
label: A
pov: Corlexi
setting: Counter-Spark shrine - first contact
word_target_min: 801
word_target_max: 1299
status: outline
---
Logline: Corlexi finds the Counter-Spark's hidden servants and learns the terrible truthâ€”the Spark and Counter-Spark are not enemies but partners in an eternal transaction that requires willing sacrifice.

Beats:
- The shrine exists in architectural impossibility, walls that fold through dimensions while gravity becomes negotiable, similar to the Debug vault but colder.
- Counter-Spark servants explain the divine symbiosis: creation requires destruction, order requires chaos, and both require conscious agents to feed the cosmic engine.
- Corlexi realizes she's been chosen not to serve but to becomeâ€”the Counter-Spark needs a mortal avatar to balance the Spark's growing influence through Guild operations.
- The price is revealed: she must accept the Counter-Spark's essence, gaining divine power while losing her humanity piece by piece.
- Decision point: she accepts the transformation, beginning her evolution from Corlexi into Xilcore, Counter-Spark's mortal voice.